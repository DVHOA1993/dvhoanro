
let chat = [
    {
        id: 0,
        value: 0,
    },
    {
        id: 1,
        value: 1,
    },
    {
        id: 2,
        value: 2,
    },
    {
        id: 3,
        value: 3,
    }
    ,
    {
        id: 4,
        value: 4,
    }
    ,
    {
        id: 5,
        value: 5,
    }
    ,
    {
        id: 6,
        value: 6,
    }
    ,
    {
        id: 7,
        value: 7,
    },
    {
        id: 8,
        value: 8,
    },
    {
        id: 9,
        value: 9,
    },
  

    {
        id: 14,
        value: 1,
    },
    {
        id: 15,
        value: 2,
    },
    {
        id: 16,
        value: 3,
    }
    ,
    {
        id: 17,
        value: 4,
    }
    ,
    {
        id: 18,
        value: 5,
    }
    ,
    {
        id: 19,
        value: 6,
    }
    ,
    {
        id: 20,
        value: 7,
    },
    {
        id: 21,
        value: 8,
    },
    {
        id: 22,
        value: 9,
    },
    
    {
        id: 27,
        value: 1,
    },
    {
        id: 28,
        value: 2,
    },
    {
        id: 29,
        value: 3,
    }
    ,
    {
        id: 30,
        value: 4,
    }
    ,
    {
        id: 31,
        value: 5,
    }
    ,
    {
        id: 32,
        value: 6,
    }
    ,
    {
        id: 33,
        value: 7,
    },
    {
        id: 34,
        value: 8,
    },
    {
        id: 35,
        value: 9,
    },
   
    {
        id: 40,
        value: 1,
    },
    {
        id: 41,
        value: 2,
    },
    {
        id: 42,
        value: 3,
    }
    ,
    {
        id: 43,
        value: 4,
    }
    ,
    {
        id: 44,
        value: 5,
    }
    ,
    {
        id: 45,
        value: 6,
    }
    ,
    {
        id: 46,
        value: 7,
    },
    {
        id: 47,
        value: 8,
    },
    {
        id: 48,
        value: 9,
    },
    
];

module.exports = chat;
